<?php 
$koneksi = mysqli_connect("localhost","root","","ppdb_2021");
?>